package com.android.databluesv5;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

public class DrawingCircular extends SurfaceView implements SurfaceHolder.Callback   {
	float x,y;
	private Context context;
	
	String[] data = new String[10];
	
	FunctionCircular df = new FunctionCircular();
	
	Canvas canvas;
	Paint p = new Paint();
	
	int quan = 4;
	int i = 0;	
	
	int px = (int) getResources().getDisplayMetrics().density * 1;
	
	
    private Canvas c;
  
    private AnimationThread thread;
      
    public DrawingCircular(Context context, AttributeSet attrs) {
        super(context, attrs);
          
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);
        thread = new AnimationThread(holder);
         
    }
    
    public void delete(){
    	for(int ctr = 0 ; ctr < data.length - 1 ; ctr++){
    		data[ctr] = data[ctr+1];
    	}
    	data[9] = null;
    	
    	i--;
    	thread.setRunning(true);
    }
    
    public void setSize(int quant){
    	quan = quant;
    	
    	thread.setRunning(true);
    }
    
    public void setData(String axe){
    	data[i] = axe;
    	i++;
    	
       thread.setRunning(true);
       }
    
    public void reset(){
    	for(int ctr = 0 ; ctr < 10 ; ctr++){
    		data[ctr] = null;
    	}
    	i = 0;
    	
    	thread.setRunning(true);
    }
    
    class AnimationThread extends Thread {
    	private boolean mRun;       
        private SurfaceHolder mSurfaceHolder;        
        
        public AnimationThread(SurfaceHolder surfaceHolder) {
            mSurfaceHolder = surfaceHolder;
           p= new Paint();
           
        }

        @Override
        public void run() {
        	
            while (mRun) {
                c = null;
                try {
                	 c = mSurfaceHolder.lockCanvas(null);
                	 Rect bg = new Rect();
         			bg.set(0, 0, DrawingCircular.this.getWidth(), DrawingCircular.this.getHeight());
         			p.setColor(Color.rgb(172, 227, 230));
         			p.setStyle(Paint.Style.FILL);
         			c.drawRect(bg, p);
         			
         			p.setColor(Color.BLACK);
         			p.setStyle(Paint.Style.STROKE);
         			p.setTextSize(13*px);
         			bg.set(1,1,DrawingCircular.this.getWidth()-1,DrawingCircular.this.getHeight()-1);
         			c.drawRect(bg,p);
                     synchronized(mSurfaceHolder){                    		
                    	doDraw(c);                    	
                     }
                    	
                        
                } catch (Exception e) {                 
                    e.printStackTrace();
                }finally {
                    if (c != null) {
                        mSurfaceHolder.unlockCanvasAndPost(c);
                    }
                }
                try {
                	//sleep ka na dito
                	sleep(300);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
            
        }

        private void doDraw(Canvas canvas) {
            int initial = 110;
            int x = 70;
            int y = 50;
           if(data[0] == null && data[1] == null ){
           	return;
           }
           int ctr = 0;
           
           //444444444444444444
           if(quan == 4){
            for(int i = 0; i < data.length; i++){
            	if(data[i] == null && data[i+1] == null){
            		break;
            	}
            	if(i==11){
            		break;
            	}
            	Rect r = new Rect(initial*px,100*px,(initial+y)*px,70*px);
            	
            	if(ctr == 0){
	        	r = new Rect(initial*px,100*px,(initial+y)*px,70*px);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",(initial + 3)*px,90*px, p);
	        	else
		        	canvas.drawText(data[i]+"",(initial + 3)*px,90*px, p);
            	}
            	else if(ctr == 1){
    	        r = new Rect(initial*px,130*px,(initial+y)*px,100*px);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",(initial + 3)*px,120*px, p);
	        	else
		        	canvas.drawText(data[i]+"",(initial + 3)*px,120*px, p);
            	}
            	else if(ctr == 2){
    	        r = new Rect(initial*px,100*px,initial+y*px,70*px);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",(initial + 3)*px,90*px, p);
	        	else
		        	canvas.drawText(data[i]+"",(initial + 3)*px,90*px, p);
            	}
            	else if(ctr == 3){
        	    r = new Rect(180*px,70*px,(180+y)*px,40*px);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",183*px,60*px, p);
	        	else
		        	canvas.drawText(data[i]+"",183*px,60*px, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
	        	canvas.drawRect(r, p);
	        	ctr++;
	        	initial = initial + x;
            }
           }
           
           //5555555555555555555
           if(quan == 5){
        	   initial = 60;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,100,initial+y,70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,90, p);
            	}
               	else if(ctr == 1){
       	        r = new Rect(initial,140,initial+y,110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 2){
       	        r = new Rect(initial,140,initial+y,110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 3){
           	    r = new Rect(initial, 100, initial+y, 70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,90, p);
            	}
               	else if(ctr == 4){
               	r = new Rect(165, 60, 165+y, 30);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",165 + 3,50, p);
	        	else
		        	canvas.drawText(data[i]+"",165 + 3,50, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
   	        	if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
         //6
           if(quan == 6){
        	   initial = 60;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,100,initial+y,70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,90, p);
            	}
               	else if(ctr == 1){
       	        r = new Rect(initial,140,initial+y,110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 2){
       	        r = new Rect(initial,140,initial+y,110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 3){
           	    r = new Rect(initial, 100, initial+y, 70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,90, p);
            	}
               	else if(ctr == 4){
               	r = new Rect(200, 60, 200+y, 30);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",200 + 3,50, p);
	        	else
		        	canvas.drawText(data[i]+"",200 + 3,50, p);
            	}
               	else if(ctr == 5){
               	r = new Rect(130, 60, 130+y, 30);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",130 + 3,50, p);
	        	else
		        	canvas.drawText(data[i]+"",130 + 3,50, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
   	        	if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
           //77777777
           if(quan == 7){
        	   initial = 60;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,120,initial+y,90);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,110, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,110, p);
            	}
               	else if(ctr == 1){
       	        r = new Rect(initial,160,initial+y,130);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,150, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,150, p);
            	}
               	else if(ctr == 2){
       	        r = new Rect(initial,160,initial+y,130);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,150, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,150, p);
            	}
               	else if(ctr == 3){
           	    r = new Rect(initial, 120, initial+y, 90);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,110, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,110, p);
            	}
               	else if(ctr == 4){
               	r = new Rect(220, 80, 220+y, 50);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",220 + 3,70, p);
	        	else
		        	canvas.drawText(data[i]+"",220 + 3,70, p);
            	}
               	else if(ctr == 5){
               	r = new Rect(165, 40, 165+y, 10);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",165 + 3,30, p);
	        	else
		        	canvas.drawText(data[i]+"",165 + 3,30, p);
            	}
               	else if(ctr == 6){
               	r = new Rect(110, 80, 110+y, 50);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",110 + 3,70, p);
	        	else
		        	canvas.drawText(data[i]+"",110 + 3,70, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
   	        	if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
         //88888
           if(quan == 8){
        	   initial = 60;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,140,initial+y,110);
   	        	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 1){
       	        r = new Rect(initial,180,initial+y,150);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,170, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,170, p);
               	}
               	else if(ctr == 2){
       	        r = new Rect(initial,180,initial+y,150);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,170, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,170, p);
            	}
               	else if(ctr == 3){
           	    r = new Rect(initial, 140, initial+y, 110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,130, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3,130, p);
            	}
               	else if(ctr == 4){
               	r = new Rect(initial - x, 100, initial - x +y, 70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",initial - x + 3,90, p);
	        	else
		        	canvas.drawText(data[i]+"",initial + 3 - x,90, p);
            	}
               	else if(ctr == 5){
               	r = new Rect(200, 60, 200 + y, 30);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",203,50, p);
	        	else
		        	canvas.drawText(data[i]+"",203,50, p);
            	}
               	else if(ctr == 6){
               	r = new Rect(130, 60, 130 + y, 30);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",133,50, p);
	        	else
		        	canvas.drawText(data[i]+"",133,50, p);
            	}
               	else if(ctr == 7){
                r = new Rect(60, 100, 60 + y, 70);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",63,90, p);
	        	else
		        	canvas.drawText(data[i]+"",63,90, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
   	        	if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
         //99999
           if(quan == 9){
        	   initial = 40;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,110,initial+y,80);
   	        	if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,100, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,100, p);
               	}
               	else if(ctr == 1){
       	        r = new Rect(70,160, 70+y,130);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",70,150, p);
	        	else
		        	canvas.drawText(data[i]+"",70,150, p);
            	}
               	else if(ctr == 2){
       	        r = new Rect(130,195, 130+y,165);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",133,185, p);
	        	else
		        	canvas.drawText(data[i]+"",133,185, p);
            	}
               	else if(ctr == 3){
           	    r = new Rect(200, 195, 200+y, 165);
           	    if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",203,185, p);
	        	else
		        	canvas.drawText(data[i]+"",203,185, p);
            	}
               	else if(ctr == 4){
               	r = new Rect(260, 160, 260 + y, 130);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",263,150, p);
	        	else
		        	canvas.drawText(data[i]+"",263,150, p);
            	}
               	else if(ctr == 5){
               	r = new Rect(280, 110, 280 + y, 80);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",283,100, p);
	        	else
		        	canvas.drawText(data[i]+"",283,100, p);
            	}
               	else if(ctr == 6){
               	r = new Rect(220, 70, 220 + y, 40);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",223,60, p);
	        	else
		        	canvas.drawText(data[i]+"",223,60, p);
            	}
               	else if(ctr == 7){
                r = new Rect(160, 35, 160 + y, 5);
                if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",163,25, p);
	        	else
		        	canvas.drawText(data[i]+"",163,25, p);
            	}
               	else if(ctr == 8){
                r = new Rect(100, 70, 100 + y, 40);
                if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",103,60, p);
	        	else
		        	canvas.drawText(data[i]+"",103,60, p);
            	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
   	        	if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
         //101010101010
           if(quan == 10){
        	   initial = 40;
               for(int i = 0; i < data.length; i++){
               	if(data[i] == null && data[i+1] == null){
               		break;
               	}
               	if(i==11){
               		break;
               	}
               	Rect r = new Rect(initial,100,initial+y,70);
               	
               	if(ctr == 0){
   	        	r = new Rect(initial,100,initial+y,70);
   	        	if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);
               	}
               	else if(ctr == 1){
       	        r = new Rect(40,140, 40 + y,110);
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",43,130, p);
	        	else
		        	canvas.drawText(data[i]+"",43,130, p);
               	}
               	else if(ctr == 2){
       	        r = new Rect(110,160, 110+y,130);  
       	        if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",113,150, p);
	        	else
		        	canvas.drawText(data[i]+"",113,150, p);
               	}
               	else if(ctr == 3){
           	    r = new Rect(180, 195, 180+y, 165);
           	    if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",183,185, p);
	        	else
		        	canvas.drawText(data[i]+"",183,185, p);
               	}
               	else if(ctr == 4){
               	r = new Rect(250, 160, 250 + y, 130);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",253,150, p);
	        	else
		        	canvas.drawText(data[i]+"",253,150, p);
               	}
               	else if(ctr == 5){
               	r = new Rect(320, 140, 320 + y, 110);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",323,130, p);
	        	else
		        	canvas.drawText(data[i]+"",323,130, p);
               	}
               	else if(ctr == 6){
               	r = new Rect(320, 100, 320 + y, 70);
               	if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",323,90, p);
	        	else
		        	canvas.drawText(data[i]+"",323,90, p);
               	}
               	else if(ctr == 7){
                r = new Rect(250, 70, 250 + y, 40);
                if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",253,60, p);
	        	else
		        	canvas.drawText(data[i]+"",253,60, p);
               	}
               	else if(ctr == 8){
                r = new Rect(180, 35, 180 + y, 5);
                if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",183,25, p);
	        	else
		        	canvas.drawText(data[i]+"",183,25, p);
               	}
               	else if(ctr == 9){
                r = new Rect(110, 70, 110 + y, 40);
                if(data[i].length() > 6)
	        		canvas.drawText(data[i].substring(0, 6)+"",113,60, p);
	        	else
		        	canvas.drawText(data[i]+"",113,60, p);
               	}
            	else if(ctr >= quan){
            		r = new Rect();
            	}
            	
               	
   	        	canvas.drawRect(r, p);
   	        	
   	        	/*if(data[i].length() > 6)
   	        		canvas.drawText(data[i].substring(0, 6)+"",initial + 3,90, p);
   	        	else
   		        	canvas.drawText(data[i]+"",initial + 3,90, p);*/
   	        	/*if(i>0){
   		        	canvas.drawLine(initial + y - x, 43, initial + y + 15 - x, 43, p);
   		        	canvas.drawText(">", initial + y + 14 - x, 47, p);
   	        	}
   	        	if(i==0){
   		        	canvas.drawText("[head]",initial - 5 + 20, 115, p);
   	        	}else
   	        	{
   	        		canvas.drawText("[" + i + "]",initial - 4 + 20,80, p);
   	        	}*/
   	        	ctr++;
   	        	initial = initial + x;
               }
              }
           
           
            }
            
		public void setRunning(boolean b) {
            mRun = b;
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }
 
    public void surfaceCreated(SurfaceHolder holder) {
    	   for(int i =0;i<10;i++){
    		   data[i] = null;
    	   }
        thread.setRunning(true);     	   
        thread.start();
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        thread.setRunning(false);
        while (retry) {
            try {
                thread.join();
                retry = false;
            } catch (InterruptedException e) {
            
            }
        }
    }
}