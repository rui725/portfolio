package com.android.databluesv5;

import java.util.Locale;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class circular extends Activity {

	String hold, hold1;
	DrawingCircular d;
	TextToSpeech speech;
	TextView algo;
	 Button b,bm,br,brem,bs;
	int ctr = 0, ctrlink = 0;
	
	Dialog howto;
	Menu mvoice;
	boolean voice = true;
	
	FunctionCircular x;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.circular_layout);
       
        getActionBar().setDisplayShowHomeEnabled(false);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setTitle("Topics");
        
        speech=new TextToSpeech(getApplicationContext(), 
        new TextToSpeech.OnInitListener() {
        @Override
        public void onInit(int status) {
        if(status != TextToSpeech.ERROR){
        speech.setLanguage(Locale.US);
        } 
        }
        });
        
        x = new FunctionCircular();
     /*   getActionBar().setTitle("Link List: Circular");
        getActionBar().setDisplayShowHomeEnabled(false);*/
        
      //  Toast.makeText(getApplicationContext(), "Default size of Circle is 4. Min = 4, Max = 10.\nString inputted will be cut to the length of 6",Toast.LENGTH_LONG).show();
        
        speech = new TextToSpeech(getApplicationContext(), 
			      new TextToSpeech.OnInitListener() {
			      @Override
			      public void onInit(int status) {
			         if(status != TextToSpeech.ERROR){
			             speech.setLanguage(Locale.US);
			            }
			         else{
			        	 //Toast.makeText(getApplicationContext(), "Beep",Toast.LENGTH_LONG).show();
			         }
			         }
			      });
        
         b = (Button)findViewById(R.id.btnCircularEnter);
         brem = (Button)findViewById(R.id.btnCircularRemove);
         br = (Button)findViewById(R.id.btnResetCircular);
         bs = (Button)findViewById(R.id.btnSizeCircular);
        algo = (TextView)findViewById(R.id.tvAlgoWriteCircular);
        
        final EditText f = (EditText)findViewById(R.id.etCircularData);
        final EditText f2 =  (EditText)findViewById(R.id.etSizeCircular);
        
        final FunctionCircular x = new FunctionCircular();
        d = (DrawingCircular)findViewById(R.id.svCircular);
        
        
        b.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				
				InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 

				inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
				
				// TODO Auto-generated method stub
				if(f.getText().toString().matches("")){
					 Toast.makeText(getApplicationContext(), "NO INPUT ON DATA",Toast.LENGTH_LONG).show();
				 }
				else if(ctrlink == 10){
					 Toast.makeText(getApplicationContext(), "Data Quantity at Maximum",Toast.LENGTH_LONG).show();
				}
				else{
				
						x.add(f.getText());
						operate();
						d.setData(f.getText().toString());
						//operate();
						if(f.getText().toString().length() > 6)
							hold = f.getText().toString().substring(0, 6);
						else
							hold = f.getText().toString();
						f.setText("");
						ctrlink++;
					 }
			}
        	
        });
        
        bs.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				
				InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 

				inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
				
				// TODO Auto-generated method stub
				if(f2.getText().toString().equals(""))
					Toast.makeText(getApplicationContext(), "No Input",Toast.LENGTH_LONG).show();
				else if(Integer.parseInt(f2.getText().toString()) < 4 || Integer.parseInt(f2.getText().toString()) > 10)
					Toast.makeText(getApplicationContext(), "Input must be either greater than or equal to 4, or less than or equal10.",Toast.LENGTH_LONG).show();
				else if(Integer.parseInt(f2.getText().toString()) >= 4 || Integer.parseInt(f2.getText().toString()) <= 10)
				d.setSize(Integer.parseInt(f2.getText().toString()));
			}
        	
        });
        
        brem.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if(x.size() == 0){
					Toast.makeText(getApplicationContext(), "No DATA available to be removed.",Toast.LENGTH_LONG).show();
				}else{
				x.remove(1);
				d.delete();
				f.setText("");
				}
			}
        	
        });
        
        br.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				do{
					x.remove(1);
					d.reset();
				}while(x.size()!=0);
			}
        	
        });
     
    }

  public void operate(){
		
    	
    	new Thread(new Runnable(){
    		String num;
    		int i,k;
    			public void run(){
    				
    			try {
    				
    				Thread.sleep(2000);
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                            // display toast here;                    	
                            	writeAlgo("Creates new node\n\nNode n = new Node;");
                            	
                            }  });
    				Thread.sleep(4000);
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                            // display toast here;                    	
                            	writeAlgo("Insert value of DATA inside the new node n\n\nn->Data = "+hold);
                            
                            }  });
    				
    				if(!((ctr-1) != 0))
    					{Thread.sleep(8800);}
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                        	int prev = x.size()-1;
                        		if((ctr-1) != 0){
                        		writeAlgo("Node before New Node points to the New Node\n\nn->Next = n(" + hold + ")");
                        		}
                            }  });
    				
    				     
    			} catch (Exception e) {
    				e.printStackTrace();
    				//Toast.makeText(getApplicationContext(), "ERROR" + e,
    				//		Toast.LENGTH_LONG).show();

    			}
    			//Thread.interrupted();
    			
    			}
    		}).start();
    	}
  
	public void writeAlgo(String msg){
		algo.append("\n"+msg);
		
		if(voice)
		speech.speak(msg, TextToSpeech.QUEUE_FLUSH, null);
		
		while(speech.isSpeaking()){
		
			try{
			Thread.sleep(100);
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        mvoice = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	switch(item.getItemId()){
    	case R.id.HowTo:Toast.makeText(getApplicationContext(), "RED BORDER - represent for the max heap\n GREEN BORDER -> the variable to be replace into another variable\n YELLOW BORDER -> place which the variable will be replace.", Toast.LENGTH_LONG).show();
    		howto = new Dialog(this);
    		howto.setContentView(R.layout.howto_layout);
    		ImageView imv = (ImageView)howto.findViewById(R.id.howtopic);
    						imv.setImageResource(R.drawable.l3);
    						howto.setCancelable(true);
    						howto.setTitle("How to ?");
    						
    						howto.show();
    						
    						
    	break;
    	case R.id.voiceControl: 
			if(voice){
				Toast.makeText(getApplicationContext(), "Voice off", Toast.LENGTH_SHORT).show();
				
				voice = false;
				mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode);
				
			}else{
				voice= true;
				
				Toast.makeText(getApplicationContext(), "Voice On", Toast.LENGTH_SHORT).show();
				mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode_off);
			}
			break;
    	case android.R.id.home: finish();
    					break;
    	}
       
        return super.onOptionsItemSelected(item);
    }
    
/*    @Override
    protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
    
    speech.stop();
    
    speech.shutdown();
    
    finish();
    }*/
}
