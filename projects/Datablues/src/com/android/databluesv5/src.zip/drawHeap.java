package com.android.databluesv5;


import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class drawHeap extends SurfaceView implements SurfaceHolder.Callback   {
	float x,y;
	int m,type;
	Rect rec[];
	int[] data = new int[10];
    private  int[] arrData;
	Canvas canvas;
	Paint p = new Paint();
	Paint t = new Paint();
	Paint box1 = new Paint();
	Paint box2 = new Paint();
	Paint MHbox = new Paint();
	Paint MHbox2 = new Paint();
    private Canvas c;
    private AnimationThread thread;
    boolean done = false;
    boolean nxt = false;
	int px = (int) getResources().getDisplayMetrics().density * 1;
    public drawHeap(Context context, AttributeSet attrs) {
        super(context, attrs);
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);
        thread = new AnimationThread(holder);   
    }
    
    public void setInteger(int[] num){
    	for(int i = 0; i < num.length; i++){
    		data[i] = num[i];
    		done = false;
    	}
       //if(done){
     	   arrData = data;
      // }
    	
       rec= new Rect[num.length];
       thread.setRunning(true);
       }
    public void setMHindex(int colorIndex,int typ){
    	m = colorIndex;
    	type = typ;
    	done = true;
       }
    
    class AnimationThread extends Thread {
    	private boolean mRun;       
        private SurfaceHolder mSurfaceHolder;        
        public AnimationThread(SurfaceHolder surfaceHolder) {
            mSurfaceHolder = surfaceHolder;
            p= new Paint();
        }

        @Override
        public void run() {
            while (mRun) {
                c = null;
                try {
                	c = mSurfaceHolder.lockCanvas(null);
                	Rect bg = new Rect();
         			bg.set(0, 0, drawHeap.this.getWidth(), drawHeap.this.getHeight());
         			p.setColor(Color.rgb(172, 227, 230));
         			p.setStyle(Paint.Style.FILL);
         			c.drawRect(bg, p);
         			p.setColor(Color.BLACK);
         			p.setStyle(Paint.Style.STROKE);
         			p.setTextSize(20);
         			box1.setColor(Color.GREEN);
                	box1.setStyle(Style.STROKE);
                	box1.setShadowLayer(2,2,2, Color.GREEN);
                	box2.setColor(Color.RED);
                	box2.setStyle(Style.STROKE);
                	box2.setShadowLayer(2,2,2, Color.YELLOW);
        			MHbox.setColor(Color.RED);
        			MHbox.setStyle(Style.STROKE);
        			MHbox.setShadowLayer(2,2,2, Color.RED);
        			t.setColor(Color.BLACK);
         			t.setStyle(Paint.Style.STROKE);
         			t.setTextSize(20);
         			bg.set(1,1,drawHeap.this.getWidth()-1,drawHeap.this.getHeight()-1);
         			c.drawRect(bg,p);
                     synchronized(mSurfaceHolder){
                    	 doDraw(c,m);
                    	 
                    	 if(m!=-1){ 
                    		 doDraw(c,m);
                    	 }
                     }        
                } catch (Exception e) {                 
                    e.printStackTrace();
                }finally {
                    if (c != null) {
                        mSurfaceHolder.unlockCanvasAndPost(c); 
                    }
                }
                try {	
                	if(!nxt){
                		sleep(2000);
                	}else{
					sleep(2000);
                	}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }
 
        private void doDraw(Canvas canvas,int o)  {
        	int px = (int) (getResources().getDisplayMetrics().density * 1);
        	Paint pt = new Paint();
        	pt.setTextSize(10*px);
        	int addloc = 15;
         	canvas.drawText("Users Data:", 10,((getHeight()/2)+100), pt);
         	for(int w = 0; w < data.length;w++){
         		if(arrData[w]!=-1){
         			canvas.drawText(arrData[w]+" ",addloc,((getHeight()/2)+130), t);
         			addloc = addloc + (20*px);
         			}
         	}
         	int i = 0;         	
            if(data[i]!= -1){
            	    Rect r21 = new Rect(20*px,50*px,70*px, 20*px);
            	    rec[i]=r21;
            	    canvas.drawRect(r21, p);
            	    canvas.drawText(data[i]+"",40*px,40*px, pt);
    		       	canvas.drawText("["+i+"]",40*px,70*px, pt);
    		       	i++;}
            if(data[i]!= -1){
            	    Rect r22 = new Rect(80*px,50*px,130*px,20*px);
            	    rec[i]=r22;
          			canvas.drawRect(r22, p);
          			canvas.drawText(data[i]+"",100*px,40*px, pt);
          			canvas.drawText("["+i+"]",100*px,70*px, pt);
          			    i++;}	
            if(data[i]!= -1){
            	   Rect r23 = new Rect(140*px,50*px,190*px,20*px);
            	   rec[i]=r23;
           	       canvas.drawRect(r23, p);
    			   canvas.drawText(data[i]+"",160*px,40*px, pt);
    			   canvas.drawText("["+i+"]",160*px,70*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	   Rect r24 = new Rect(200*px,50*px,250*px,20*px);
            	   rec[i]=r24;
    			   canvas.drawRect(r24, p);
    			   canvas.drawText(data[i]+"",220*px,40*px, pt);
    			   canvas.drawText("["+i+"]",220*px,70*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	   Rect r25 = new Rect(260*px, 50*px,310*px,20*px);
            	   rec[i]=r25;
           	       canvas.drawRect(r25, p);
    			   canvas.drawText(data[i]+"",280*px,40*px, pt);
    			   canvas.drawText("["+i+"]",280*px,70*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	   Rect r26 = new Rect(20*px,85*px,70*px,115*px);
            	   rec[i]=r26;
           	       canvas.drawRect(r26, p);
    			   canvas.drawText(data[i]+"",40*px,105*px, pt);
    			   canvas.drawText("["+i+"]",40*px, 135*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	  Rect r27 = new Rect(80*px,85*px,130*px,115*px);
            	  rec[i]=r27;
           	      canvas.drawRect(r27, p);
    			   canvas.drawText(data[i]+"",100*px,105*px, pt);
    			   canvas.drawText("["+i+"]",100*px,135*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	  Rect r28 = new Rect(140*px,85*px,190*px,115*px);
            	  rec[i]= r28;
           	   canvas.drawRect(r28,p);
    			   canvas.drawText(data[i]+"",160*px,105*px, pt);
    			   canvas.drawText("["+i+"]",160*px,135*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	  Rect r29 = new Rect(200*px,85*px,250*px,115*px);
            	  rec[i]=r29;
           	   canvas.drawRect(r29, p);
    			   canvas.drawText(data[i]+"",220*px,105*px, pt);
    			   canvas.drawText("["+i+"]",220*px,135*px, pt);
    			       	i++;}
            if(data[i]!= -1){
            	  Rect r30 = new Rect(260*px,85*px,310*px,115*px);
            	  rec[i]=r30;
           	   canvas.drawRect(r30, p);
    			   canvas.drawText(data[i]+"",280*px,105*px, pt);
    			   canvas.drawText("["+i+"]",280*px,135*px, pt);
    			       	i++;
    			}
            
            //if(type==7 && done){           	
           // canvas.drawRect(rec[o], MHbox); 
          //  done = false;
          //  }
            if(type==8 && done){
                canvas.drawRect(rec[o], box1);
                done = false;
            }
            if(type==9 && done){
                canvas.drawRect(rec[o], box2);
                done = false;
            }
    		return;
                
      }//end do draw

        protected void runOnUiThread(Runnable runnable) {
				// TODO Auto-generated method stub
			}
		public void setRunning(boolean b) {
            mRun = b;
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }
    public void surfaceCreated(SurfaceHolder holder) {
    	
    	   for(int i =0;i<10;i++){
    		   data[i] = -1;
    	   }
        thread.setRunning(true);     	   
        thread.start();
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        thread.setRunning(false);
        while (retry) {
            try {
                thread.join();
                retry = false;
            } catch (InterruptedException e) {
            
            }
        }
    }

}
	