package com.android.databluesv5;

import java.util.Locale;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class singly extends Activity {

	TextToSpeech speech;
	TextView algo;
	EditText f2;
	String hold, hold1;
	
	DrawingSingly d;
	int ctr = 0;
	
	SinglyFunction x;
	
    boolean fix, rem;
    Dialog howto;
    boolean voice = true;
    int[] xx = new int[10];
    Menu mvoice;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.singly_layout);
        
        getActionBar().setDisplayShowHomeEnabled(false);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setTitle("Topics");
       
        speech=new TextToSpeech(getApplicationContext(), 
        new TextToSpeech.OnInitListener() {
        @Override
        public void onInit(int status) {
        if(status != TextToSpeech.ERROR){
        speech.setLanguage(Locale.US);
        } 
        }
        });
        
    //    Toast.makeText(getApplicationContext(), "String inputted will be cut to the length of 2",Toast.LENGTH_LONG).show();
        //Toast.makeText(getApplicationContext(), "String inputted will be cut to the length of 6",Toast.LENGTH_LONG).show();
        
        speech = new TextToSpeech(getApplicationContext(), 
			      new TextToSpeech.OnInitListener() {
			      @Override
			      public void onInit(int status) {
			         if(status != TextToSpeech.ERROR){
			             speech.setLanguage(Locale.US);
			            }
			         else{
			        	 Toast.makeText(getApplicationContext(), "Beep",Toast.LENGTH_LONG).show();
			         }
			         }
			      });
        
        x = new SinglyFunction();
        
        final EditText f = (EditText)findViewById(R.id.etSinglyData);
        

        for(int i = 0 ; i < 10 ; i++){
        	xx[i] = i;
        }
        
        d = (DrawingSingly)findViewById(R.id.svSingly);
        //setContentView(d);
        
        f2 = (EditText)findViewById(R.id.etPositionSingly);
        Button b = (Button)findViewById(R.id.btnEnterSingly);
        Button brem = (Button)findViewById(R.id.btnRemoveSingly);
        Button fb = (Button)findViewById(R.id.btnSinglyPositionEnter);
        Button br = (Button)findViewById(R.id.btnResetSingly);
        algo = (TextView)findViewById(R.id.tvAlgoWriteSingly);
        algo.setMovementMethod(new ScrollingMovementMethod());
		f.setText("");
		f2.setText("");
		
        b.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {

				InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 

				inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
				
				if(f.getText().toString().matches("")){
					 Toast.makeText(getApplicationContext(), "NO INPUT ON DATA",Toast.LENGTH_LONG).show();
				 }else{
					 d.setData(f.getText().toString());
						operate();
						if(f.getText().toString().length() > 2){
					        x.add(f.getText().toString().substring(0, 2));
					        hold = f.getText().toString().substring(0, 2);
						}
						else{
							x.add(f.getText());
							hold = f.getText().toString();
						}
						hold1 = f2.getText().toString();
						f.setText("");
						f2.setText("");
						ctr++;
					 }
			}
        	
        });
        
        brem.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				if(x.size() == 0){
					Toast.makeText(getApplicationContext(), "No DATA available to be removed.",Toast.LENGTH_LONG).show();
				}
				else{
				rem = true;
				operate();
				x.remove(1);
				d.delete();
				f.setText("");
				f2.setText("");
				}
			}        	
        });
        
        fb.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {

				InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 

				inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
				
				if(f.getText().toString().matches("")){
					Toast.makeText(getApplicationContext(), "NO INPUT ON DATA",Toast.LENGTH_LONG).show();
				}
				else if(f2.getText().toString().matches("")){
					Toast.makeText(getApplicationContext(), "NO INPUT ON POSITION",Toast.LENGTH_LONG).show();
				}
				else if(ctr >= 8){
					 Toast.makeText(getApplicationContext(), "LIST IS FULL",Toast.LENGTH_LONG).show();
				}
				else{
					if(Integer.parseInt(f2.getText().toString())>x.size()){
						operate();
						Toast.makeText(getApplicationContext(), "Value inserted at last position, due to input being greater than last position.",Toast.LENGTH_LONG).show();
						if(f.getText().toString().length() > 2){
					        Toast.makeText(getApplicationContext(), "String inputted was cut to the length of 2",Toast.LENGTH_LONG).show();
							d.setData(f.getText().toString().substring(0, 2));
					        hold = f.getText().toString().substring(0, 2);
						}
						else{
							d.setData(f.getText().toString());
							hold = f.getText().toString();
						}
						hold1 = f2.getText().toString();
						ctr++;
					}
					else{
						if(Integer.parseInt(f2.getText().toString()) == 1 && ctr > 1){
							fix = true;
							operate();
							x.add(f.getText(), 1);
							if(f.getText().toString().length() > 2){
						        Toast.makeText(getApplicationContext(), "String inputted was cut to the length of 4",Toast.LENGTH_LONG).show();
								d.fixedsetData(f.getText().toString().substring(0, 2), Integer.parseInt(f2.getText().toString()));
								hold = f.getText().toString().substring(0, 2);
							}
							else{
								d.fixedsetData(f.getText().toString(), Integer.parseInt(f2.getText().toString()));
								hold = f.getText().toString();
							}
							hold1 = f2.getText().toString();
							
							ctr++;
						}
						else{
							fix = true;
							operate();
							x.add(f.getText(), Integer.parseInt(f2.getText().toString()));
							d.fixedsetData(f.getText().toString(), Integer.parseInt(f2.getText().toString()));
							if(f.getText().toString().length() > 4){
						        Toast.makeText(getApplicationContext(), "String inputted was cut to the length of 4",Toast.LENGTH_LONG).show();
								hold = f.getText().toString().substring(0, 4);
							}
							else
								hold = f.getText().toString();
							hold1 = f2.getText().toString();
							ctr++;
						}
					}
					f.setText("");
					f2.setText("");
				}
			}
        	
        });
        
        br.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				do{
					x.remove(1);
					d.reset();
				}while(x.size()!=0);
				algo.setText("");
			}
        	
        });
        
        
        
    }

    public void operate(){
		
    	if(fix){
    		new Thread(new Runnable(){
        		String num;
        		int i,k;
        			public void run(){
        				
        			try {
        				
        				runOnUiThread(new Runnable(){
                            @Override 
                            public void run() {
                                // display toast here;                    	
                                	writeAlgo("Create New Node. New Node MUST connect to ahead Node to save the link\nn->Next = n*" + (Integer.parseInt(hold1)+1) + "\n");
                                	
                                }  });
        				if(!((ctr-1) != 0))
        					{Thread.sleep(3500);}
        				else
        					{Thread.sleep(5000);}
        				runOnUiThread(new Runnable(){
                            @Override 
                            public void run() {
                                // display toast here;
                            	int prev = x.size()-1;
                            		if((ctr-1) == 0 && hold1.equals(("0"))){
                            		writeAlgo("New node is Head.\n\nn->Next = n(tail)");
                            		}
                            		else if(hold1.equals("0")){
                            		writeAlgo("New node is Head.\n\nn->Next = n*" + (Integer.parseInt(hold1)+1));
                            		}
                            		else if((ctr-1) == 1 || hold1.equals(("1"))){
                            			Toast.makeText(getApplicationContext(), "Critical Difference of Doubly to Singly",Toast.LENGTH_LONG).show();
                            		writeAlgo("New node ALSO points to Node " + (Integer.parseInt(hold1)-1) + "\n\nn->Prev = n(head)");
                            		}else{
                            			Toast.makeText(getApplicationContext(), "Critical Difference of Doubly to Singly",Toast.LENGTH_LONG).show();
                            		writeAlgo("New node ALSO points to Node " + (Integer.parseInt(hold1)-1) + "\n\nn->Prev = n*" + (Integer.parseInt(hold1)-1));
                            		}
                                }  });
        				
        				runOnUiThread(new Runnable(){
                            @Override 
                            public void run() {
                                // display toast here;
                            	int prev = x.size()-1;
                            		writeAlgo("Connection of list done.");
                                }  });
        				
        				     
        			} catch (Exception e) {
        				e.printStackTrace();
        				//Toast.makeText(getApplicationContext(), "ERROR" + e,
        				//		Toast.LENGTH_LONG).show();

        			}
        			//Thread.interrupted();
        			
        			}
        		}).start();
    	}
    	
    	else if(rem){
        	new Thread(new Runnable(){
        		String num;
        		int i,k;
        			public void run(){
        				
        			try {
        				
        				runOnUiThread(new Runnable(){
                            @Override 
                            public void run() {
                                // display toast here;                    	
                                	writeAlgo("\nRemoving a Node.\nn*temp = n(head)->Next;\nn(head)->Next = null;\nn(head) = n*temp;\nn*temp = null;");
                                }  });
        				
        				     
        			} catch (Exception e) {
        				e.printStackTrace();
        				//Toast.makeText(getApplicationContext(), "ERROR" + e,
        				//		Toast.LENGTH_LONG).show();

        			}
        			//Thread.interrupted();
        			
        			}
        		}).start();
        		
        	
        	
        }
    	
    	else{
    	new Thread(new Runnable(){
    		String num;
    		int i,k;
    			public void run(){
    				
    			try {
    				
    				Thread.sleep(2000);
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                            // display toast here;                    	
                            	writeAlgo("Creates new node\n\nNode n = new Node;");
                            	
                            }  });
    				Thread.sleep(4000);
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                            // display toast here;                    	
                            	writeAlgo("Insert value of DATA inside the new node n\n\nn->Data = "+hold);
                            
                            }  });
    				Thread.sleep(8800);
    				runOnUiThread(new Runnable(){
                        @Override 
                        public void run() {
                            // display toast here;
                        	SinglyFunction x = new SinglyFunction();	
                        	int prev = x.size()-1;
                        		if((ctr-1) == 0){
                        		writeAlgo("New node is head.\n\nn->Next = n(tail)");
                        		}else{
                        		writeAlgo("Node before New Node points to New Node\n\nn->Next = n(" + x.get(prev) + ")");
                        		}
                        		//writeAlgo("New node pointers points to the previous Node\n\nn->Next = n" + x.get(prev));
                            //	writeAlgo("n->next = n(previous node)");
                        		//}
                            }  });
    				
    				     
    			} catch (Exception e) {
    				e.printStackTrace();
    				//Toast.makeText(getApplicationContext(), "ERROR" + e,
    				//		Toast.LENGTH_LONG).show();

    			}
    			//Thread.interrupted();
    			
    			}
    		}).start();
    		
    	
    	}
    	

        fix = false;
        rem = false;
    }
    
	public void writeAlgo(String msg){
		algo.append("\n"+msg);
		if(voice)
		speech.speak(msg, TextToSpeech.QUEUE_FLUSH, null);
		
		while(speech.isSpeaking()){
		
			try{
			Thread.sleep(100);
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}
	}
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        mvoice = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	switch(item.getItemId()){
    	case R.id.HowTo:Toast.makeText(getApplicationContext(), "RED BORDER - represent for the max heap\n GREEN BORDER -> the variable to be replace into another variable\n YELLOW BORDER -> place which the variable will be replace.", Toast.LENGTH_LONG).show();
    		howto = new Dialog(this);
    		howto.setContentView(R.layout.howto_layout);
    		ImageView imv = (ImageView)howto.findViewById(R.id.howtopic);
    						imv.setImageResource(R.drawable.l3);
    						howto.setCancelable(true);
    						howto.setTitle("How to ?");
    						
    						howto.show();
    						
    						
    	break;
    	case R.id.voiceControl: 
			if(voice){
				Toast.makeText(getApplicationContext(), "Voice off", Toast.LENGTH_SHORT).show();
				
				voice = false;
				mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode);
				
			}else{
				voice= true;
				
				Toast.makeText(getApplicationContext(), "Voice On", Toast.LENGTH_SHORT).show();
				mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode_off);
			}
			break;
    	case android.R.id.home: finish();
    					break;
    	}

        return super.onOptionsItemSelected(item);
    }
    
 /*   @Override
    protected void onPause() {
    // TODO Auto-generated method stub
    super.onPause();
    
    speech.stop();
    
    speech.shutdown();
    
    finish();
    }*/
}
