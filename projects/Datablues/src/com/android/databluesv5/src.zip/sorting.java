package com.android.databluesv5;



import java.util.Locale;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class sorting extends Activity { 
	private  int[] a;
    private  int n;
    private  int left;
    private  int right;
    private  int largest;
    
    TextToSpeech ttobj;
    EditText input;
    Button enter1;
    TextView showAlgo;
    public int[] numConverted;
    drawHeap d;
    Dialog howto;
    
    Menu mvoice;
    
    boolean voice = true;//on
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.heap_layout);
		showAlgo = (TextView)findViewById(R.id.tvAlgoWriteHeap);
		showAlgo.setMovementMethod(new ScrollingMovementMethod());
		input = (EditText)findViewById(R.id.etInputHeap);
		getActionBar().setDisplayShowHomeEnabled(false);
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setTitle("Topics");
		ttobj=new TextToSpeech(getApplicationContext(), 
			      new TextToSpeech.OnInitListener() {
			      @Override
			      public void onInit(int status) {
			         if(status != TextToSpeech.ERROR){
			             ttobj.setLanguage(Locale.US);
			            }				
			         }
			      });
		enter1 = (Button)findViewById(R.id.btnPlayHeap);
		d = (drawHeap)findViewById(R.id.svHeap);
		enter1.setOnClickListener(new OnClickListener(){
			
			@Override
			public void onClick(View v) {
				String str = input.getText().toString();
				boolean checker = false;
				
				if(str.matches("")){
					Toast.makeText(getApplicationContext(),"No input value.", Toast.LENGTH_LONG).show();
				}else{
					for(int i = 0;i<str.length();i++){
				    	if(str.charAt(i)==' '||str.charAt(i)=='.'){
				    			 checker = false;
					    		 break; 
				    	}
				    	else if((str.charAt(i)>='0'&&str.charAt(i)<='9')||str.charAt(i)==','){
						 checker = true;
					    }else{
						   checker = false;
						   break;
					   }
					 
				     }
					
					String[] num = str.split(",");
					if(num.length <= 2){
						Toast.makeText(getApplicationContext(),"Number of data must be atleast 3 input.", Toast.LENGTH_LONG).show();
						checker = false;
					}
					else if(num.length > 10){
						Toast.makeText(getApplicationContext(),"Number of data have only a maximum of 10 input.", Toast.LENGTH_LONG).show();
						checker = false;
					}
					else{
						checker = true;
						numConverted = new int[num.length];
						for(int i = 0; i < numConverted.length; i++){
							numConverted[i] = Integer.parseInt(num[i]);
						}
					}
				}
				
				if(checker){
					 InputMethodManager inputManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 
				     inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),InputMethodManager.HIDE_NOT_ALWAYS);
			    d.setInteger(numConverted);
				operate();
				}
				else{
					Toast.makeText(getApplicationContext(),"Data contains invalid type of input.", Toast.LENGTH_LONG).show();
				}
			}});	
	}
	
	public void showAlg(String msg){
		showAlgo.append("\n"+msg);
		if(msg.contains("]")){
			msg = msg.replaceAll("\\]", "");
			}
		if(msg.contains("[")){
		msg = msg.replaceAll("\\[", " index of");
		}
		if(msg.contains("->")){
			msg = msg.replaceAll("\\->", " value of");
			}
		if(msg.contains("D O N E")){
			msg = msg.replaceAll("D O N E", " Done");
			}
		//if voice on then YOU CAN TALK TO ME
		if(voice)
		ttobj.speak(msg, TextToSpeech.QUEUE_FLUSH, null);
	
		while(ttobj.isSpeaking()){
			try{
			Thread.sleep(100);
			} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
			}
	}
	
			@Override
			protected void onPause() {
			// TODO Auto-generated method stub
			super.onPause();
			ttobj.stop();
			ttobj.shutdown();
			finish();
			
	} 
			
			// Build-Heap Function
			public void buildheap( final int []a){
				n=a.length-1;
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("Build Heap"+"\n for i = array length divide 2, i >= 0, decrease i");
		        }  });
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for(int i=n/2;i>=0;i--){	
			    d.setInteger(a);
				maxheap(a,i);
				}
				}
				// Max-Heap Function
				public void maxheap(int[] a, int i){
				d.setInteger(a);
				left=2*i;
				right=2*i+1;
				final int iHold2 = i;
				final int aHolder[] = a;
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("\nMaxHeap index = a["+iHold2+"]");
		        }  });
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				d.setMHindex(i, 7);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(left <= n && a[left] > a[i]){
					runOnUiThread(new Runnable(){
		                @Override 
		            public void run() {
			    	showAlg("largest l= a["+left+"] -> "+aHolder[left]);
		            }  });
				largest=left;
				}
				else{
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					runOnUiThread(new Runnable(){
		                @Override 
		            public void run() {
			    	showAlg("largest i= a["+iHold2+"] -> "+aHolder[iHold2]);
		            }  });
				largest=i;
				}
				
				if(right <= n && a[right] > a[largest]){
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
					runOnUiThread(new Runnable(){
		                @Override 
		            public void run() {
			    	showAlg("largest r= a["+right+"] -> "+aHolder[right]);
		            }  }); 
				largest=right;
				}
				if(largest!=i){
				exchange(i,largest);
				maxheap(a, largest);
				}
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
				
				// Exchange Function
				public void exchange( int i, int j){
					final int iHold3 = i;
					final int jHold1 = j;
					
				final int t=a[i];
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("\n\tswap data\nholder = a["+iHold3+"] -> "+a[iHold3]);
		        }  });
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				d.setMHindex(i, 8);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				a[i]=a[j];
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("a["+iHold3+"] = a["+jHold1+"] -> "+a[jHold1]);
		        }  });
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				d.setMHindex(j, 9);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				a[j]=t;
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("a["+jHold1+"] = holder -> "+t);
		        }  });
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				d.setMHindex(i, 8);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				d.setInteger(a);
				}
				// Sort Function
				public void sort(int []a0){
				a=a0;
				buildheap(a);
				for(int i=n;i>0;i--){
				exchange(0, i);
				n=n-1;
				maxheap(a, 0);
				}
				runOnUiThread(new Runnable(){
		            @Override 
		        public void run() {
		    	showAlg("D O N E.");
		        }  });
				}
					    
			//heap end
			    
	//heap end
			    
	public void operate(){
		new Thread(new Runnable(){
				public void run(){
				    sort(numConverted);
					try {
						Thread.sleep(2000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
		}).start();
		}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		
		mvoice = menu;
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch(item.getItemId()){
    	case R.id.HowTo:Toast.makeText(getApplicationContext(), "RED BORDER - represent for the max heap\n GREEN BORDER -> the variable to be replace into another variable\n YELLOW BORDER -> place which the variable will be replace.", Toast.LENGTH_LONG).show();
    		howto = new Dialog(this);
    		howto.setContentView(R.layout.howto_layout);
    		ImageView imv = (ImageView)howto.findViewById(R.id.howtopic);
    						imv.setImageResource(R.drawable.s2);
    						howto.setCancelable(true);
    						howto.setTitle("How to ?");    						
    						howto.show();
    						break;
    	case R.id.voiceControl: 
    					if(voice){
    						Toast.makeText(getApplicationContext(), "Voice off", Toast.LENGTH_SHORT).show();
    						
    						voice = false;
    						mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode);
    						
    					}else{
    						voice= true;
    						
    						Toast.makeText(getApplicationContext(), "Voice On", Toast.LENGTH_SHORT).show();
    						mvoice.getItem(0).setIcon(android.R.drawable.ic_lock_silent_mode_off);
    					}
    					break;
    	case android.R.id.home: finish();
    					break;
    	}
		return super.onOptionsItemSelected(item);
	}
}
